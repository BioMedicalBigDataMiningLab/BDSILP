import MeSHSimilarity
import numpy as np
import math
import matplotlib.pyplot as plt
import random
import datetime,time

def loo_cross_validation(interaction_matrix,alpha,beta):
	(rows,cols) = np.where(interaction_matrix == 1)
	positive_num = len(rows)
	sample_num = positive_num + 1
	metrics = np.zeros((1,7))
	k_folds = sample_num
	predict_matrix = np.matrix(np.zeros(interaction_matrix.shape))
	for k in range(k_folds):
		#print("-----------this is %dth cross validation-------------"%(k+1))
		train_matrix = np.matrix(interaction_matrix,copy = True)
		if k != (k_folds-1):
			train_matrix[rows[k],cols[k]] = 0
			disease_similarity_matrix = MeSHSimilarity.get_Combined_Disease_Similarity(train_matrix.T)
			microbe_similarity_matrix = MeSHSimilarity.get_Combined_Microbe_Similarity(train_matrix,rows[k])
			#disease_similarity_matrix = get_Gauss_Similarity(train_matrix.T)
			#microbe_similarity_matrix = get_Gauss_Similarity(train_matrix)
			disease_similarity_matrix = matrix_Lapalace_normalize(disease_similarity_matrix)
			microbe_similarity_matrix = matrix_Lapalace_normalize(microbe_similarity_matrix)
			#score_matrix = LPM(microbe_similarity_matrix,train_matrix,alpha)
			#score_matrix = LPD(disease_similarity_matrix,train_matrix,alpha)
			score_matrix = BDSILP(disease_similarity_matrix,microbe_similarity_matrix,train_matrix,alpha,beta)
			predict_matrix[rows[k],cols[k]] = score_matrix[rows[k],cols[k]]
		else:
			disease_similarity_matrix = MeSHSimilarity.get_Combined_Disease_Similarity(train_matrix.T)
			microbe_similarity_matrix = MeSHSimilarity.get_Combined_Microbe_Similarity2(train_matrix)
			#disease_similarity_matrix = get_Gauss_Similarity(train_matrix.T)
			#microbe_similarity_matrix = get_Gauss_Similarity(train_matrix)
			disease_similarity_matrix = matrix_Lapalace_normalize(disease_similarity_matrix)
			microbe_similarity_matrix = matrix_Lapalace_normalize(microbe_similarity_matrix)
			#score_matrix = LPM(microbe_similarity_matrix,train_matrix,alpha)
			#score_matrix = LPD(disease_similarity_matrix,train_matrix,alpha)
			score_matrix = BDSILP(disease_similarity_matrix,microbe_similarity_matrix,train_matrix,alpha,beta)
			predict_matrix[np.where(interaction_matrix == 0)] = score_matrix[np.where(interaction_matrix == 0)]
	metrics = loo_model_evaluate(interaction_matrix,predict_matrix)
	print(metrics)
	return metrics


def loo_model_evaluate(interaction_matrix,predict_matrix):
	real_score = np.matrix(np.array(interaction_matrix).flatten())
	predict_score = np.matrix(np.array(predict_matrix).flatten())
	AUPR = get_AUPR(real_score,predict_score)
	AUC = get_AUC(real_score,predict_score)
	[f1,accuracy,recall,spec,precision] = get_Metrics(real_score,predict_score)
	return [AUPR,AUC,f1,accuracy,recall,spec,precision]


def cross_validation(interaction_matrix,k_folds,seed,alpha,beta):
	(rows,cols) = np.where(interaction_matrix == 1)
	positive_num = len(rows)
	randomlist = [i for i in range(positive_num)]
	random.seed(seed)
	random.shuffle(randomlist)
	metrics = np.zeros((1,7))
	for k in range(k_folds):
		if k != (k_folds-1):
			testlist = randomlist[k*int(positive_num/k_folds):(k+1)*int(positive_num/k_folds)]
		else:
			testlist = randomlist[k*int(positive_num/k_folds):]
		train_matrix = np.matrix(interaction_matrix,copy = True)
		for i in testlist:
			train_matrix[rows[i],cols[i]] = 0
		disease_similarity_matrix = MeSHSimilarity.get_Combined_Disease_Similarity(train_matrix.T)
		microbe_similarity_matrix = MeSHSimilarity.get_Combined_Microbe_Similarity3(train_matrix)
		disease_similarity_matrix = matrix_Lapalace_normalize(disease_similarity_matrix)
		microbe_similarity_matrix = matrix_Lapalace_normalize(microbe_similarity_matrix)
		predict_matrix = BDSILP(disease_similarity_matrix,microbe_similarity_matrix,train_matrix,alpha,beta)
		metrics = metrics + model_evaluate(interaction_matrix,predict_matrix,train_matrix)
	print(metrics/(k+1))
	return metrics/(k+1)
	
def model_evaluate(interaction_matrix,predict_matrix,train_matrix):
	test_index = np.where(train_matrix==0)
	real_score = interaction_matrix[test_index]
	predict_score = predict_matrix[test_index]
	AUPR = get_AUPR(real_score,predict_score)
	AUC = get_AUC(real_score,predict_score)
	[f1,accuracy,recall,spec,precision] = get_Metrics(real_score,predict_score)
	return [AUPR,AUC,f1,accuracy,recall,spec,precision]

def get_AUPR(real_score,predict_score):
	sorted_predict_score = sorted(list(set(np.array(predict_score).flatten())))
	sorted_predict_score_num = len(sorted_predict_score)
	thresholdlist = []
	for i in range(999):
		threshold = sorted_predict_score[math.ceil(sorted_predict_score_num*(i+1)/1000)-1]
		thresholdlist.append(threshold)
	thresholds = np.matrix(thresholdlist)
	TN = np.zeros((1,len(thresholdlist)))
	TP = np.zeros((1,len(thresholdlist)))
	FN = np.zeros((1,len(thresholdlist)))
	FP = np.zeros((1,len(thresholdlist)))
	for i in range(thresholds.shape[1]):
		p_index = np.where(predict_score >= thresholds[0,i])
		TP[0,i] = len(np.where(real_score[p_index]==1)[1])
		FP[0,i] = len(np.where(real_score[p_index]==0)[1])
		n_index = np.where(predict_score < thresholds[0,i])
		FN[0,i] = len(np.where(real_score[n_index]==1)[1])
		TN[0,i] = len(np.where(real_score[n_index]==0)[1])
	precision = TP/(TP+FP)
	recall = TP/(TP+FN)
	x = list(np.array(recall).flatten())
	y = list(np.array(precision).flatten())
	xy = [(x,y) for x,y in zip(x,y)]
	xy.sort()
	x = [x for x,y in xy]
	y = [y for x,y in xy]
	x[0] = 0
	y[0] = 1
	x.append(1)
	y.append(0)
	area = 0
	for i in range(thresholds.shape[1]):
		area = area+(y[i]+y[i+1])*(x[i+1]-x[i])/2;
	#plt.plot(x,y)
	#plt.show()
	return area

def get_AUC(real_score,predict_score):
	sorted_predict_score = sorted(list(set(np.array(predict_score).flatten())))
	sorted_predict_score_num = len(sorted_predict_score)
	thresholdlist = []
	thresholdnumber = []
	for i in range(999):
		thresholdnumber.append(int(math.ceil(sorted_predict_score_num*(i+1)/1000)-1))
		threshold = sorted_predict_score[math.ceil(sorted_predict_score_num*(i+1)/1000)-1]
		thresholdlist.append(threshold)
	thresholds = np.matrix(thresholdlist)
	TN = np.zeros((1,len(thresholdlist)))
	TP = np.zeros((1,len(thresholdlist)))
	FN = np.zeros((1,len(thresholdlist)))
	FP = np.zeros((1,len(thresholdlist)))
	for i in range(thresholds.shape[1]):
		p_index = np.where(predict_score >= thresholds[0,i])
		TP[0,i] = len(np.where(real_score[p_index]==1)[1])
		FP[0,i] = len(np.where(real_score[p_index]==0)[1])
		n_index = np.where(predict_score < thresholds[0,i])
		FN[0,i] = len(np.where(real_score[n_index]==1)[1])
		TN[0,i] = len(np.where(real_score[n_index]==0)[1])
	sen = TP/(TP+FN)
	spe = TN/(TN+FP)
	x = list(np.array(1-spe).flatten())
	y = list(np.array(sen).flatten())
	xy = [(x,y) for x,y in zip(x,y)]
	xy.sort()
	x = [x for x,y in xy]
	y = [y for x,y in xy]
	x[0] = 0
	y[0] = 0
	x.append(1)
	y.append(1)
	area = 0
	for i in range(thresholds.shape[1]):
		area = area+(y[i]+y[i+1])*(x[i+1]-x[i])/2;
	#plt.plot(x,y)
	#plt.show()
	return area

def get_Metrics(real_score,predict_score):
	sorted_predict_score = sorted(list(set(np.array(predict_score).flatten())))
	sorted_predict_score_num = len(sorted_predict_score)
	thresholdlist = []
	for i in range(999):
		threshold = sorted_predict_score[math.ceil(sorted_predict_score_num*(i+1)/1000)-1]
		thresholdlist.append(threshold)
	thresholds = np.matrix(thresholdlist)
	TN = np.zeros((1,len(thresholdlist)))
	TP = np.zeros((1,len(thresholdlist)))
	FN = np.zeros((1,len(thresholdlist)))
	FP = np.zeros((1,len(thresholdlist)))
	for i in range(thresholds.shape[1]):
		p_index = np.where(predict_score >= thresholds[0,i])
		TP[0,i] = len(np.where(real_score[p_index]==1)[1])
		FP[0,i] = len(np.where(real_score[p_index]==0)[1])
		n_index = np.where(predict_score < thresholds[0,i])
		FN[0,i] = len(np.where(real_score[n_index]==1)[1])
		TN[0,i] = len(np.where(real_score[n_index]==0)[1])
	accuracy = (TP+TN)/(TP+TN+FP+FN)
	sen = TP/(TP+FN)
	recall = sen
	spec = TN/(TN+FP)
	precision = TP/(TP+FP)
	f1 = 2*recall*precision/(recall+precision)
	max_index = np.argmax(f1)
	max_f1 = f1[0,max_index]
	max_accuracy = accuracy[0,max_index]
	max_recall = recall[0,max_index]
	max_spec = spec[0,max_index]
	max_precision = precision[0,max_index]
	return [max_f1,max_accuracy,max_recall,max_spec,max_precision]

def BDSILP(disease_similarity_matrix,microbe_similarity_matrix,train_matrix,alpha,beta):
	PM = (1-alpha)*np.linalg.inv(np.eye(microbe_similarity_matrix.shape[0])-alpha*microbe_similarity_matrix)*train_matrix
	PD = ((1-alpha)*np.linalg.inv(np.eye(disease_similarity_matrix.shape[0])-alpha*disease_similarity_matrix)*train_matrix.T).T
	return beta*PM+(1-beta)*PD

def LPD(disease_similarity_matrix,train_matrix,alpha):
	PD = ((1-alpha)*np.linalg.inv(np.eye(disease_similarity_matrix.shape[0])-alpha*disease_similarity_matrix)*train_matrix.T).T
	return PD

def LPM(microbe_similarity_matrix,train_matrix,alpha):
	PM = (1-alpha)*np.linalg.inv(np.eye(microbe_similarity_matrix.shape[0])-alpha*microbe_similarity_matrix)*train_matrix
	return PM

def get_Gauss_Similarity(interacition_matrix):
	X = np.matrix(interacition_matrix,copy=True)
	delta = 1
	norm_delta = delta/np.mean(np.sum(np.power(X,2),1))
	alpha=np.power(X,2).sum(axis=1)
	similarity_matrix = np.exp(np.multiply(-norm_delta,alpha+alpha.T-2*X*X.T))
	similarity_matrix[np.isnan(similarity_matrix)] = 0
	similarity_matrix = similarity_matrix - np.diag(np.diag(similarity_matrix))
	return similarity_matrix

def matrix_Lapalace_normalize(similarity_matrix):
	similarity_matrix[np.isnan(similarity_matrix)] = 0
	if similarity_matrix.shape[0] == similarity_matrix.shape[1]:
		similarity_matrix = similarity_matrix - np.diag(np.diag(similarity_matrix))
		D = np.diag(np.array(np.sum(similarity_matrix,axis=1)).flatten())
		D = np.linalg.inv(np.sqrt(D))
		similarity_matrix = D*similarity_matrix*D
	else:
		for i in range(similarity_matrix.shape[0]):
			if np.sum(similarity_matrix[i],axis=1) == 0:
				similarity_matrix[i] = similarity_matrix[i]
			else:
				similarity_matrix[i] = similarity_matrix[i]/np.sum(similarity_matrix[i],axis=1)
	return similarity_matrix

if __name__ == "__main__":
	microbe_disease_matrix = np.matrix(np.loadtxt("Matrixofmicrobe-disease.txt"))
	loo_cross_validation(microbe_disease_matrix,0.25,0.7)
	#cross_validation(microbe_disease_matrix,5,1,0.25,0.7)


