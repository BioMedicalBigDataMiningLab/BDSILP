import math
import xlrd
import numpy as np

#calculate the MeSH similarity between Liver Neoplasms and Pancreatic Neoplasms
#Liver Neoplasms' treenumbers:C04.588.274.623|C06.301.623|C06.552.697|
#Pancreatic Neoplasms' treenumbers:C04.588.274.761|C04.588.322.475|C06.301.761|C06.689.667|C19.344.421|

def get_diseases():
	diseases = []
	rb = xlrd.open_workbook("diseases.xlsx")
	sheet1 = rb.sheets()[0]
	for row in range(sheet1.nrows):
		diseases.append(sheet1.cell_value(row,0))
	diseases.pop(0)
	return diseases
					

def get_dt_DT_Similarity2(semantic_similarity_matrix,diseasesId_dt,diseasesId_DT):
	maxSim = 0
	for diseasesId in diseasesId_DT:
		dt_DT_Sim = semantic_similarity_matrix[diseasesId_dt,diseasesId]
		if dt_DT_Sim > maxSim:
			maxSim = dt_DT_Sim
	return maxSim

def get_DT_DT_Similarity2(semantic_similarity_matrix,diseasesId_DT1,diseasesId_DT2):
	DT_DT_Sim = 0
	for diseasesId in diseasesId_DT1:
		DT_DT_Sim = DT_DT_Sim + get_dt_DT_Similarity2(semantic_similarity_matrix,diseasesId,diseasesId_DT2)
	for diseasesId in diseasesId_DT2:
		DT_DT_Sim = DT_DT_Sim + get_dt_DT_Similarity2(semantic_similarity_matrix,diseasesId,diseasesId_DT1)
	return DT_DT_Sim/(len(diseasesId_DT1)+len(diseasesId_DT2)) 

#calculate gauss association profile similarity
def get_Gauss_Similarity(interacition_matrix):
	X = np.matrix(interacition_matrix,copy=True)
	delta = 1
	norm_delta = delta/np.mean(np.sum(np.power(X,2),1))
	alpha=np.power(X,2).sum(axis=1)
	similarity_matrix = np.exp(np.multiply(-norm_delta,alpha+alpha.T-2*X*X.T))
	similarity_matrix[np.isnan(similarity_matrix)] = 0
	similarity_matrix = similarity_matrix - np.diag(np.diag(similarity_matrix))
	return similarity_matrix

#calculate the integrated disease similarity
def get_Combined_Disease_Similarity(interaction_matrix):
	semantic_similarity_matrix = np.matrix(np.loadtxt("semantic_similarity_matrix.txt"))
	semantic_similarity_matrix = semantic_similarity_matrix - np.diag(np.diag(semantic_similarity_matrix))
	disease_Gauss_Similarity = get_Gauss_Similarity(interaction_matrix)
	semantic_similarity_matrix[np.where(semantic_similarity_matrix==-1)] = disease_Gauss_Similarity[np.where(semantic_similarity_matrix==-1)]
	combined_similarity_matrix = (semantic_similarity_matrix + disease_Gauss_Similarity)/2
	return combined_similarity_matrix

def get_microbes_isfunction(interaction_matrix,diseases):
	interaction_matrix_copy = np.matrix(np.zeros(interaction_matrix.shape))
	for i in range(interaction_matrix.shape[0]):
		for j in range(interaction_matrix.shape[1]):
			if interaction_matrix[i,j] == 1 and diseases[j] != '':
				interaction_matrix_copy[i,j] = 1
	interaction_matrix_row = interaction_matrix.sum(axis=1).T
	interaction_matrix_copy_row = interaction_matrix_copy.sum(axis=1).T
	microbe_isfunction = []
	for i in range(interaction_matrix_row.shape[1]):
		if interaction_matrix_row[0,i] == interaction_matrix_copy_row[0,i] and interaction_matrix_row[0,i] > 0:
			microbe_isfunction.append(1)
		else:
			microbe_isfunction.append(0)
	return microbe_isfunction

#calculate microbe function similarity
def cal_microbe_function_similarity(interaction_matrix,semantic_similarity_matrix,row1,row2,diseases):
	diseasesId1 = []
	diseasesId2 = []
	for col in range(interaction_matrix.shape[1]):
		if interaction_matrix[row1,col] == 1:
			diseasesId1.append(col)
	for col in range(interaction_matrix.shape[1]):
		if interaction_matrix[row2,col] == 1:
			diseasesId2.append(col)
	return get_DT_DT_Similarity2(semantic_similarity_matrix,diseasesId1,diseasesId2)

#calculate the integrated microbe similarity
def get_Combined_Microbe_Similarity(interaction_matrix,rowIndex):
	microbe_function_similarity_matrix = np.matrix(np.loadtxt("microbe_function_similarity_matrix.txt"))
	semantic_similarity_matrix = np.matrix(np.loadtxt("semantic_similarity_matrix.txt"))
	diseases = get_diseases()
	microbes_isfunction = get_microbes_isfunction(interaction_matrix,diseases)
	if microbes_isfunction[rowIndex] == 1:
		for j in range(interaction_matrix.shape[0]):
			if microbes_isfunction[j] == 1:
				microbe_function_similarity_matrix[rowIndex,j] = cal_microbe_function_similarity(interaction_matrix,semantic_similarity_matrix,rowIndex,j,diseases)
				microbe_function_similarity_matrix[j,rowIndex] = microbe_function_similarity_matrix[rowIndex,j]
	else:
		for j in range(interaction_matrix.shape[0]):
			microbe_function_similarity_matrix[rowIndex,j] = -1
			microbe_function_similarity_matrix[j,rowIndex] = microbe_function_similarity_matrix[rowIndex,j]
	microbe_function_similarity_matrix = microbe_function_similarity_matrix - np.diag(np.diag(microbe_function_similarity_matrix))
	microbe_Gauss_Similarity = get_Gauss_Similarity(interaction_matrix)
	microbe_function_similarity_matrix[np.where(microbe_function_similarity_matrix==-1)] = microbe_Gauss_Similarity[np.where(microbe_function_similarity_matrix==-1)]
	combined_similarity_matrix = (microbe_function_similarity_matrix + microbe_Gauss_Similarity)/2
	return combined_similarity_matrix
	
#calculate the integrated microbe similarity
def get_Combined_Microbe_Similarity2(interaction_matrix):
	microbe_function_similarity_matrix = np.matrix(np.loadtxt("microbe_function_similarity_matrix.txt"))
	microbe_function_similarity_matrix = microbe_function_similarity_matrix - np.diag(np.diag(microbe_function_similarity_matrix))
	microbe_Gauss_Similarity = get_Gauss_Similarity(interaction_matrix)
	microbe_function_similarity_matrix[np.where(microbe_function_similarity_matrix==-1)] = microbe_Gauss_Similarity[np.where(microbe_function_similarity_matrix==-1)]
	combined_similarity_matrix = (microbe_function_similarity_matrix + microbe_Gauss_Similarity)/2
	return combined_similarity_matrix
	
#calculate the integrated microbe similarity(k-fold)
def get_Combined_Microbe_Similarity3(interaction_matrix):
	microbe_function_similarity_matrix = np.matrix(np.zeros((interaction_matrix.shape[0],interaction_matrix.shape[0])))
	semantic_similarity_matrix = np.matrix(np.loadtxt("semantic_similarity_matrix.txt"))
	diseases = get_diseases()
	microbes_isfunction = get_microbes_isfunction(interaction_matrix,diseases)
	for i in range(interaction_matrix.shape[0]):
		if microbes_isfunction[i] == 1:
			for j in range(interaction_matrix.shape[0]):
				if microbes_isfunction[j] == 1:
					microbe_function_similarity_matrix[i,j] = cal_microbe_function_similarity(interaction_matrix,semantic_similarity_matrix,i,j,diseases)
					microbe_function_similarity_matrix[j,i] = microbe_function_similarity_matrix[i,j]
				else:
					microbe_function_similarity_matrix[i,j] = -1
					microbe_function_similarity_matrix[j,i] = microbe_function_similarity_matrix[i,j]
		else:
			for j in range(interaction_matrix.shape[0]):
				microbe_function_similarity_matrix[i,j] = -1
				microbe_function_similarity_matrix[j,i] = microbe_function_similarity_matrix[i,j]
	microbe_Gauss_Similarity = get_Gauss_Similarity(interaction_matrix)
	microbe_function_similarity_matrix = microbe_function_similarity_matrix - np.diag(np.diag(microbe_function_similarity_matrix))
	microbe_function_similarity_matrix[np.where(microbe_function_similarity_matrix==-1)] = microbe_Gauss_Similarity[np.where(microbe_function_similarity_matrix==-1)]
	combined_similarity_matrix = (microbe_function_similarity_matrix + microbe_Gauss_Similarity)/2
	return combined_similarity_matrix




